import sys
import pandas as pd
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import (QApplication, QMainWindow, QFileDialog, QTextEdit, QLineEdit, QVBoxLayout, QHBoxLayout)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import PlaACC
import TissACC
import os


class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1000, 600)

        # 主布局（水平布局：左侧菜单 + 右侧内容）
        main_h_layout = QHBoxLayout()
        main_h_layout.setSpacing(0)

        # ========== 左侧菜单栏 ==========
        self.menu_widget = QtWidgets.QWidget()
        self.menu_widget.setFixedWidth(150)
        self.menu_widget.setStyleSheet("""
            background-color: rgb(40, 44, 52);
        """)

        menu_layout = QVBoxLayout(self.menu_widget)
        menu_layout.setContentsMargins(5, 20, 5, 20)
        menu_layout.setSpacing(15)

        # 菜单按钮样式
        menu_button_style = """
            QPushButton {
                color: white;
                font: 12pt "Times New Roman";
                background-color: rgb(126,127,142);
                border: none;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """

        # Home 按钮
        self.btn_home = QtWidgets.QPushButton("Home")
        self.btn_home.setStyleSheet(menu_button_style)
        self.btn_home.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_home)

        # Instruction 按钮
        self.btn_instruction = QtWidgets.QPushButton("Instruction")
        self.btn_instruction.setStyleSheet(menu_button_style)
        self.btn_instruction.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_instruction)

        # Plasma 按钮
        self.btn_plasma = QtWidgets.QPushButton("Plasma")
        self.btn_plasma.setStyleSheet(menu_button_style)
        self.btn_plasma.setIcon(QtGui.QIcon("image/Plasma.png"))
        self.btn_plasma.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_plasma)

        # Tissue 按钮
        self.btn_tissue = QtWidgets.QPushButton("Tissue")
        self.btn_tissue.setStyleSheet(menu_button_style)
        self.btn_tissue.setIcon(QtGui.QIcon("image/Tissue.png"))
        self.btn_tissue.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_tissue)

        # 添加 Batch-Pla 按钮（位于Tissue按钮下方）
        self.btn_batch_pla = QtWidgets.QPushButton("Batch-Pla")
        self.btn_batch_pla.setStyleSheet(menu_button_style)
        self.btn_batch_pla.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_batch_pla)

        # 添加 Batch-Tissue 按钮（位于Batch-Pla按钮下方）
        self.btn_batch_tissue = QtWidgets.QPushButton("Batch-Tiss")
        self.btn_batch_tissue.setStyleSheet(menu_button_style)
        self.btn_batch_tissue.setIconSize(QtCore.QSize(24, 24))
        menu_layout.addWidget(self.btn_batch_tissue)

        # 添加弹簧使按钮靠上（除Exit按钮外）
        menu_layout.addStretch()

        # 创建一个新的QWidget来包含图标和文字
        logo_widget = QtWidgets.QWidget()
        logo_layout = QtWidgets.QVBoxLayout(logo_widget)
        logo_layout.setContentsMargins(0, 0, 0, 0)
        logo_layout.setSpacing(5)

        # 加载图标
        logo_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap("image/tubiao.png")
        scaled_pixmap = pixmap.scaledToWidth(100, QtCore.Qt.SmoothTransformation)
        logo_label.setPixmap(scaled_pixmap)
        logo_label.setAlignment(QtCore.Qt.AlignCenter)
        logo_layout.addWidget(logo_label)

        # 添加文字
        text_label = QtWidgets.QLabel("lncNSCLCDiag")
        text_label.setStyleSheet("color: white; font: 12pt 'Times New Roman';")
        text_label.setAlignment(QtCore.Qt.AlignCenter)
        logo_layout.addWidget(text_label)

        menu_layout.addWidget(logo_widget)

        # Exit 按钮移到左侧菜单栏底部
        self.pushButton_4 = QtWidgets.QPushButton("Exit")
        self.pushButton_4.setStyleSheet(menu_button_style)
        menu_layout.addWidget(self.pushButton_4)

        main_h_layout.addWidget(self.menu_widget)

        # ========== 右侧内容区域 ==========
        self.content_widget = QtWidgets.QWidget()
        self.content_widget.setStyleSheet("background-color: rgb(44, 49, 58);")
        content_layout = QVBoxLayout(self.content_widget)

        # 顶部按钮区域（原功能按钮）
        top_widget = QtWidgets.QWidget()
        # 将 top_layout 定义为类的属性
        self.top_layout = QtWidgets.QHBoxLayout(top_widget)

        self.pushButton = QtWidgets.QPushButton("Open")
        self.pushButton.setFixedSize(150, 40)
        icon = QtGui.QIcon("image/icon.png")
        self.pushButton.setIcon(icon)
        self.pushButton.setIconSize(QtCore.QSize(16, 16))
        self.pushButton.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.top_layout.addWidget(self.pushButton)

        # 文件名文本框
        self.file_name_text_box = QLineEdit()
        self.file_name_text_box.setPlaceholderText("Add csv")
        self.file_name_text_box.setStyleSheet("""
            background-color: rgb(126,127,142); 
            color: white; 
            border: 0px; 
            border-radius: 5px;
            font: 10pt "Times New Roman";
        """)
        self.file_name_text_box.setFixedSize(450, 40)
        self.top_layout.addWidget(self.file_name_text_box)

        content_layout.addWidget(top_widget)

        # 中间区域
        middle_widget = QtWidgets.QWidget()
        middle_layout = QtWidgets.QVBoxLayout(middle_widget)

        # 图片区域
        image_layout = QtWidgets.QHBoxLayout()

        # 右侧图表区域
        self.right_widget = QtWidgets.QWidget()
        self.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 2px solid rgb(126,127,142); 
            border-radius: 5px;
        """)
        self.right_layout = QtWidgets.QVBoxLayout(self.right_widget)
        self.right_layout.setContentsMargins(0, 0, 0, 0)
        image_layout.addWidget(self.right_widget, stretch=1)
        self.right_widget.setMinimumSize(300, 200)
        self.right_widget.setMaximumSize(10000, 10000)

        # 左侧图表区域
        self.bottom_left_widget = QtWidgets.QWidget()
        self.bottom_left_widget.setStyleSheet("""
            background-color: transparent; 
            border: 2px solid rgb(126,127,142); 
            border-radius: 5px;
        """)
        self.bottom_left_layout = QtWidgets.QVBoxLayout(self.bottom_left_widget)
        image_layout.addWidget(self.bottom_left_widget, stretch=1)

        middle_layout.addLayout(image_layout, stretch=3)
        self.bottom_left_widget.setMinimumSize(300, 200)
        self.bottom_left_widget.setMaximumSize(10000, 10000)

        # 文本区域
        bottom_right_widget = QtWidgets.QWidget()
        bottom_right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 2px solid rgb(126,127,142); 
            border-radius: 5px;
        """)
        bottom_right_layout = QtWidgets.QVBoxLayout(bottom_right_widget)

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            color: white; 
            border-radius: 5px;
            font: 14pt "Times New Roman";
        """)
        self.text_edit.setMinimumSize(1000, 100)
        self.text_edit.setMaximumSize(1000, 200)
        bottom_right_layout.addWidget(self.text_edit)
        middle_layout.addWidget(bottom_right_widget, stretch=1)

        content_layout.addWidget(middle_widget)

        main_h_layout.addWidget(self.content_widget)

        central_widget = QtWidgets.QWidget()
        central_widget.setLayout(main_h_layout)
        Form.setCentralWidget(central_widget)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "lncNSCLCDiag"))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.setFixedSize(1000, 600)

        # 连接信号槽
        self.ui.pushButton.clicked.connect(self.open_csv_file)
        self.ui.btn_instruction.clicked.connect(self.show_instruction_page)
        self.ui.btn_plasma.clicked.connect(self.show_plasma_page)
        self.ui.btn_tissue.clicked.connect(self.show_tissue_page)
        self.ui.btn_batch_pla.clicked.connect(self.show_batch_pla_page)
        self.ui.btn_batch_tissue.clicked.connect(self.show_batch_tissue_page)
        self.ui.btn_home.clicked.connect(self.show_home_page)
        self.ui.pushButton_4.clicked.connect(self.close)

        self.selected_file_path = None

        # 初始化显示首页
        self.show_home_page()
        self.setStyleSheet("background-color: rgb(40, 44, 52);")

    def show_home_page(self):
        """显示首页内容"""
        self.clear_content()

        # 清除顶部按钮区域除 Open 按钮和文件名文本框外的所有部件
        for i in reversed(range(self.ui.top_layout.count())):
            widget = self.ui.top_layout.itemAt(i).widget()
            if widget and widget not in [self.ui.pushButton, self.ui.file_name_text_box]:
                widget.deleteLater()

        self.ui.pushButton.hide()
        self.ui.file_name_text_box.hide()

        for i in reversed(range(self.ui.right_layout.count())):
            widget = self.ui.right_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        self.ui.bottom_left_widget.hide()
        self.ui.text_edit.parentWidget().hide()

        home_widget = QtWidgets.QWidget()
        home_widget.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            border-radius: 5px;
        """)
        home_layout = QtWidgets.QVBoxLayout(home_widget)
        # 进一步减小间距
        home_layout.setSpacing(0)
        home_layout.setContentsMargins(0, 0, 0, 0)

        home_widget.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

        # 图标部分
        icon_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap("image/tubiao.png")

        # 控制图片大小
        target_width = 300
        scaled_pixmap = pixmap.scaledToWidth(target_width, QtCore.Qt.SmoothTransformation)

        icon_label.setPixmap(scaled_pixmap)
        icon_label.setAlignment(QtCore.Qt.AlignCenter)  # 关键：保持居中
        icon_label.setSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)  # 允许自适应
        icon_label.setContentsMargins(0, 60, 0, 0)

        home_layout.addWidget(icon_label)

        from PyQt5.QtWidgets import QSpacerItem, QSizePolicy
        # 图标相关代码
        home_layout.addWidget(icon_label)
        # 添加垂直方向的QSpacerItem，这里高度设为50，可按需调整
        spacer = QSpacerItem(20, 0, QSizePolicy.Minimum, QSizePolicy.Fixed)
        home_layout.addItem(spacer)
        # 标题
        title_label = QtWidgets.QLabel("lncNSCLCDiag")
        font = QtGui.QFont()
        font.setFamily("Berlin Sans FB Demi")
        font.setPointSize(30)
        title_label.setFont(font)
        title_label.setStyleSheet("color: pink;")
        title_label.setAlignment(QtCore.Qt.AlignCenter)
        title_label.setContentsMargins(0, 0, 0, 100)

        home_layout.addWidget(title_label)

        # 移除 right_widget 的边框
        self.ui.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            border-radius: 0px;
        """)

        self.ui.right_layout.addWidget(home_widget)
        self.ui.right_layout.setStretch(0, 1)

    def show_instruction_page(self):
        """显示Instruction页面"""
        self.clear_content()

        # 清除顶部按钮区域除 Open 按钮和文件名文本框外的所有部件
        for i in reversed(range(self.ui.top_layout.count())):
            widget = self.ui.top_layout.itemAt(i).widget()
            if widget and widget not in [self.ui.pushButton, self.ui.file_name_text_box]:
                widget.deleteLater()

        self.ui.pushButton.hide()
        self.ui.file_name_text_box.hide()

        for i in reversed(range(self.ui.right_layout.count())):
            widget = self.ui.right_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        self.ui.bottom_left_widget.hide()
        self.ui.text_edit.parentWidget().hide()

        # 清空右侧布局
        while self.ui.right_layout.count():
            widget = self.ui.right_layout.takeAt(0).widget()
            if widget:
                widget.deleteLater()

        instruction_text = QTextEdit()
        instruction_text.setReadOnly(True)
        instruction_text.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            color: white; 
            border-radius: 5px;
            font-family: "Times New Roman";
            margin - top: 0;
            padding - top: 0px;
        """)  # 统一字体族，后续通过HTML标签控制字号

        # 使用HTML标签构建富文本内容
        html_content = """
            <div style="font-size: 12pt;">  
                Click “Plasma” to enter the non-invasive module. <br>  <!-- 换行 -->
                Click “Open” to enter the plasma RNA-seq containing the expression of 9 lncRNAs (AL445524.1, MMP25-AS1, OR2A1-AS1, OVCH1-AS1, RTCA-AS1, SNHG1, SUGT1P4-STRA6LP-CCDC180, TRG-AS1, TTC28-AS1) within the csv file. <br>
                Click “Plasma Analysis” for diagnosis. <br><br>  <!-- 空行 -->

                Click “Tissue” to enter the invasive module. <br>
                Click “Open” to enter the tumour tissue RNA-seq containing the expression of 9 lncRNAs within the csv file. <br>
                Click “Tissue Analysis” for diagnose. <br><br>

                <b style="color: red;">The diagnostic results on this platform are not diagnostic standards and are only for reference.</b> <br>  
                Patients with a Confidence percentage less than 30% have a low probability of developing the disease and can be continuously observed. <br>
                Patients with a Confidence percentage between 30% and 80% have a certain probability of developing the disease and can be judged together with other symptoms. <br>
                Patients with a percentage greater than 80% are highly suspected of having the disease and more in-depth examination is recommended.
            </div>
        """

        instruction_text.setHtml(html_content)  # 使用setHtml渲染富文本
        instruction_text.setMinimumSize(790, 800)
        instruction_text.setMaximumSize(790, 800)

        # 移除 right_widget 的边框
        self.ui.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            border-radius: 0px;
        """)

        self.ui.right_layout.addWidget(instruction_text)

    def show_plasma_page(self):
        """显示Plasma分析页面"""
        self.clear_content()
        self.restore_right_widget_style()

        # 恢复 左下角 和 文本编辑区域
        self.ui.bottom_left_widget.show()
        self.ui.text_edit.parentWidget().show()
        # 设置布局边距为0
        self.ui.bottom_left_layout.setContentsMargins(0, 0, 0, 0)
        # 设置布局间距为0
        self.ui.bottom_left_layout.setSpacing(0)

        # 显示 Open 按钮和文件名文本框
        self.ui.pushButton.show()
        self.ui.file_name_text_box.show()
        self.ui.pushButton_2 = QtWidgets.QPushButton("Plasma Analysis")
        # 设置按钮的固定大小为 (150, 40)
        self.ui.pushButton_2.setFixedSize(150, 40)
        # 设置按钮样式表
        self.ui.pushButton_2.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.ui.pushButton_2.clicked.connect(self.on_plasma_clicked)
        self.ui.top_layout.addWidget(self.ui.pushButton_2)

    def show_tissue_page(self):
        """显示Tissue分析页面"""
        self.clear_content()
        self.restore_right_widget_style()

        # 恢复 左下角 和 文本编辑区域
        self.ui.bottom_left_widget.show()
        self.ui.text_edit.parentWidget().show()

        # 显示 Open 按钮和文件名文本框
        self.ui.pushButton.show()
        self.ui.file_name_text_box.show()
        self.ui.pushButton_3 = QtWidgets.QPushButton("Tissue Analysis")
        self.ui.pushButton_3.setFixedSize(150, 40)
        # 设置按钮样式表
        self.ui.pushButton_3.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.ui.pushButton_3.clicked.connect(self.on_frozen_clicked)
        self.ui.top_layout.addWidget(self.ui.pushButton_3)

    def restore_right_widget_style(self):
        """恢复 right_widget 的默认样式"""
        self.ui.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 2px solid rgb(126,127,142); 
            border-radius: 5px;
        """)

    def clear_content(self):
        """清空内容区域"""
        # 清除可能存在的临时按钮
        for i in reversed(range(self.ui.top_layout.count())):
            widget = self.ui.top_layout.itemAt(i).widget()
            if widget and widget not in [self.ui.pushButton, self.ui.file_name_text_box]:
                widget.deleteLater()

        # 清除图表
        for i in reversed(range(self.ui.right_layout.count())):
            self.ui.right_layout.itemAt(i).widget().deleteLater()
        for i in reversed(range(self.ui.bottom_left_layout.count())):
            self.ui.bottom_left_layout.itemAt(i).widget().deleteLater()

        # 清空文本
        self.ui.text_edit.clear()
        self.ui.right_layout.update()
        self.ui.bottom_left_layout.update()

    def open_csv_file(self):
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(self, '选择 CSV 文件', '', 'CSV 文件 (*.csv)')
        if file_path:
            self.selected_file_path = file_path  # 存储完整文件路径
            file_name = os.path.basename(file_path)  # 获取文件名
            self.ui.file_name_text_box.setText(file_name)  # 在文本框显示文件名
            try:
                df = pd.read_csv(file_path, header=None)
                # 确保数据行数足够
                if df.shape[0] >= 2:
                    genes = df.iloc[0].tolist()
                    expressions = df.iloc[1].tolist()
                    # 尝试转换数据类型
                    try:
                        expressions = [float(x) for x in expressions]
                    except ValueError as ve:
                        print(f"数据类型转换出错: {ve}")
                    fig = Figure(figsize=(5, 5))
                    ax = fig.add_subplot(111)
                    ax.bar(genes, expressions)
                    ax.set_xlabel('Genes')
                    ax.set_ylabel('Expression Levels')
                    ax.yaxis.set_major_formatter('{x:.2f}')
                    ax.set_xticklabels(genes, fontsize=8, rotation=30)  # 添加rotation参数，设置旋转角度为45度
                    fig.subplots_adjust(left=0.2, bottom=0.25, right=0.9, top=0.9)  # 调整子图布局

                    canvas = FigureCanvas(fig)
                    for i in reversed(range(self.ui.right_layout.count())):
                        widget = self.ui.right_layout.itemAt(i).widget()
                        if widget is not None:
                            widget.setParent(None)
                    self.ui.right_layout.addWidget(canvas)
                else:
                    print("CSV文件数据格式错误，行数不足")
            except Exception as e:
                print(f"读取文件时出错: {e}")
        else:
            self.ui.file_name_text_box.setText("")  # 取消选择时清空文本框
            self.selected_file_path = None  # 清空文件路径属性

    def on_plasma_clicked(self):
        if self.selected_file_path:
            fig, info = PlaACC.generate_figure(self.selected_file_path)
            if fig:
                canvas = FigureCanvas(fig)
                for i in reversed(range(self.ui.bottom_left_layout.count())):
                    widget = self.ui.bottom_left_layout.itemAt(i).widget()
                    if widget is not None:
                        widget.setParent(None)
                self.ui.bottom_left_layout.addWidget(canvas)
                canvas.draw()  # 强制重绘图形
            if info:
                self.ui.text_edit.setPlainText(info)
        else:
            print("请先通过Open按钮选择文件")

    def on_frozen_clicked(self):
        if self.selected_file_path:
            try:
                fig, info = TissACC.generate_figure(self.selected_file_path)
                if fig:
                    canvas = FigureCanvas(fig)
                    for i in reversed(range(self.ui.bottom_left_layout.count())):
                        widget = self.ui.bottom_left_layout.itemAt(i).widget()
                        if widget is not None:
                            widget.setParent(None)
                    self.ui.bottom_left_layout.addWidget(canvas)
                if info:
                    self.ui.text_edit.setPlainText(info)
            except Exception as e:
                print(f"在 generate_figure 函数中发生异常: {e}")
        else:
            print("请先通过Open按钮选择文件")

    def show_batch_pla_page(self):
        """显示Batch-Pla批量分析页面"""
        self.clear_content()

        # 清除顶部按钮区域除 Open 按钮和文件名文本框外的所有部件
        for i in reversed(range(self.ui.top_layout.count())):
            widget = self.ui.top_layout.itemAt(i).widget()
            if widget and widget not in [self.ui.pushButton, self.ui.file_name_text_box]:
                widget.deleteLater()

        self.ui.pushButton.hide()
        self.ui.file_name_text_box.hide()

        for i in reversed(range(self.ui.right_layout.count())):
            widget = self.ui.right_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        self.ui.bottom_left_widget.hide()
        self.ui.text_edit.parentWidget().hide()

        # 创建顶部操作区域（只包含Open按钮、文件名显示框和分析按钮）
        batch_top_widget = QtWidgets.QWidget()
        batch_top_layout = QtWidgets.QHBoxLayout(batch_top_widget)

        # 1. 打开文件按钮
        self.btn_batch_open = QtWidgets.QPushButton("Open")
        self.btn_batch_open.setFixedSize(150, 40)
        self.btn_batch_open.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.btn_batch_open.clicked.connect(self.batch_open_csv_file)
        batch_top_layout.addWidget(self.btn_batch_open)

        # 2. 文件名显示框
        self.batch_file_text = QLineEdit()
        self.batch_file_text.setPlaceholderText("Add csv")
        self.batch_file_text.setStyleSheet("""
            background-color: rgb(126,127,142); 
            color: white; 
            border: 0px; 
            border-radius: 5px;
            font: 10pt "Times New Roman";
        """)
        self.batch_file_text.setFixedSize(450, 40)
        self.batch_file_text.setReadOnly(True)  # 设置为只读
        batch_top_layout.addWidget(self.batch_file_text)

        # 3. 分析按钮
        self.btn_batch_analyze = QtWidgets.QPushButton("Batch_Pla Analysis")
        self.btn_batch_analyze.setFixedSize(150, 40)
        self.btn_batch_analyze.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.btn_batch_analyze.clicked.connect(self.run_batch_analysis)
        batch_top_layout.addWidget(self.btn_batch_analyze)

        # 添加到顶部布局
        self.ui.top_layout.addWidget(batch_top_widget)

        # 创建底部操作区域（包含下载按钮）
        batch_bottom_widget = QtWidgets.QWidget()
        batch_bottom_layout = QtWidgets.QHBoxLayout(batch_bottom_widget)
        batch_bottom_layout.setAlignment(QtCore.Qt.AlignCenter)  # 居中对齐

        # 4. 下载按钮（初始隐藏，分析完成后显示）
        self.btn_download = QtWidgets.QPushButton("Download")
        self.btn_download.setFixedSize(150, 40)
        self.btn_download.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(61, 186, 124); /* 绿色按钮 */
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(50, 150, 100);
            }
        """)
        self.btn_download.clicked.connect(self.download_results)
        self.btn_download.hide()  # 新增：初始隐藏按钮

        batch_bottom_layout.addWidget(self.btn_download)

        # 创建中央内容区域
        center_widget = QtWidgets.QWidget()
        center_layout = QtWidgets.QVBoxLayout(center_widget)

        # 添加应用标题和logo
        title_widget = QtWidgets.QWidget()
        title_layout = QtWidgets.QVBoxLayout(title_widget)

        # 图标部分
        icon_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap("image/tubiao.png")
        target_width = 280
        scaled_pixmap = pixmap.scaledToWidth(target_width, QtCore.Qt.SmoothTransformation)
        icon_label.setPixmap(scaled_pixmap)
        icon_label.setAlignment(QtCore.Qt.AlignCenter)
        icon_label.setContentsMargins(0, 0, 0, 0)

        # 标题
        title_label = QtWidgets.QLabel("lncNSCLCDiag")
        font = QtGui.QFont()
        font.setFamily("Berlin Sans FB Demi")
        font.setPointSize(30)
        title_label.setFont(font)
        title_label.setStyleSheet("color: pink;")
        title_label.setAlignment(QtCore.Qt.AlignCenter)
        title_label.setContentsMargins(0, 0, 0, -100)

        title_layout.addWidget(icon_label)
        title_layout.addWidget(title_label)

        center_layout.addWidget(title_widget)
        center_layout.addStretch(1)  # 添加伸缩项使内容居中

        # 移除 right_widget 的边框
        self.ui.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            border-radius: 0px;
        """)

        # 将中央内容和底部按钮添加到right_layout
        self.ui.right_layout.addWidget(center_widget, stretch=1)
        self.ui.right_layout.addWidget(batch_bottom_widget)

        # 初始化变量
        self.batch_file_path = None
        self.batch_result_df = None

    def show_batch_tissue_page(self):
        self.clear_content()

        # 清除顶部按钮区域除 Open 按钮和文件名文本框外的所有部件
        for i in reversed(range(self.ui.top_layout.count())):
            widget = self.ui.top_layout.itemAt(i).widget()
            if widget and widget not in [self.ui.pushButton, self.ui.file_name_text_box]:
                widget.deleteLater()

        self.ui.pushButton.hide()
        self.ui.file_name_text_box.hide()

        for i in reversed(range(self.ui.right_layout.count())):
            widget = self.ui.right_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        self.ui.bottom_left_widget.hide()
        self.ui.text_edit.parentWidget().hide()

        # 创建顶部操作区域（只包含Open按钮、文件名显示框和分析按钮）
        batch_top_widget = QtWidgets.QWidget()
        batch_top_layout = QtWidgets.QHBoxLayout(batch_top_widget)

        # 1. 打开文件按钮
        self.btn_batch_open = QtWidgets.QPushButton("Open")
        self.btn_batch_open.setFixedSize(150, 40)
        self.btn_batch_open.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.btn_batch_open.clicked.connect(self.batch_open_csv_file)
        batch_top_layout.addWidget(self.btn_batch_open)

        # 2. 文件名显示框
        self.batch_file_text = QLineEdit()
        self.batch_file_text.setPlaceholderText("Add csv")
        self.batch_file_text.setStyleSheet("""
            background-color: rgb(126,127,142); 
            color: white; 
            border: 0px; 
            border-radius: 5px;
            font: 10pt "Times New Roman";
        """)
        self.batch_file_text.setFixedSize(450, 40)
        self.batch_file_text.setReadOnly(True)  # 设置为只读
        batch_top_layout.addWidget(self.batch_file_text)

        # 3. 分析按钮
        self.btn_batch_analyze = QtWidgets.QPushButton("Batch_Tiss Analysis")
        self.btn_batch_analyze.setFixedSize(150, 40)
        self.btn_batch_analyze.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(126,127,142);
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(135,136,172);
            }
        """)
        self.btn_batch_analyze.clicked.connect(self.run_batch_tiss_analysis)
        batch_top_layout.addWidget(self.btn_batch_analyze)

        # 添加到顶部布局
        self.ui.top_layout.addWidget(batch_top_widget)

        # 创建底部操作区域（包含下载按钮）
        batch_bottom_widget = QtWidgets.QWidget()
        batch_bottom_layout = QtWidgets.QHBoxLayout(batch_bottom_widget)
        batch_bottom_layout.setAlignment(QtCore.Qt.AlignCenter)  # 居中对齐

        # 4. 下载按钮（初始隐藏，分析完成后显示）
        self.btn_download = QtWidgets.QPushButton("Download")
        self.btn_download.setFixedSize(150, 40)
        self.btn_download.setStyleSheet("""
            QPushButton {
                color: white;
                font: 10pt "Times New Roman";
                background-color: rgb(61, 186, 124); /* 绿色按钮 */
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: rgb(50, 150, 100);
            }
        """)
        self.btn_download.clicked.connect(self.download_results)
        self.btn_download.hide()  # 新增：初始隐藏按钮

        batch_bottom_layout.addWidget(self.btn_download)

        # 创建中央内容区域
        center_widget = QtWidgets.QWidget()
        center_layout = QtWidgets.QVBoxLayout(center_widget)

        # 添加应用标题和logo
        title_widget = QtWidgets.QWidget()
        title_layout = QtWidgets.QVBoxLayout(title_widget)

        # 图标部分
        icon_label = QtWidgets.QLabel()
        pixmap = QtGui.QPixmap("image/tubiao.png")
        target_width = 280
        scaled_pixmap = pixmap.scaledToWidth(target_width, QtCore.Qt.SmoothTransformation)
        icon_label.setPixmap(scaled_pixmap)
        icon_label.setAlignment(QtCore.Qt.AlignCenter)
        icon_label.setContentsMargins(0, 0, 0, 0)

        # 标题
        title_label = QtWidgets.QLabel("lncNSCLCDiag")
        font = QtGui.QFont()
        font.setFamily("Berlin Sans FB Demi")
        font.setPointSize(30)
        title_label.setFont(font)
        title_label.setStyleSheet("color: pink;")
        title_label.setAlignment(QtCore.Qt.AlignCenter)
        title_label.setContentsMargins(0, 0, 0, -100)

        title_layout.addWidget(icon_label)
        title_layout.addWidget(title_label)

        center_layout.addWidget(title_widget)
        center_layout.addStretch(1)  # 添加伸缩项使内容居中

        # 移除 right_widget 的边框
        self.ui.right_widget.setStyleSheet("""
            background-color: transparent; 
            border: 0px; 
            border-radius: 0px;
        """)

        # 将中央内容和底部按钮添加到right_layout
        self.ui.right_layout.addWidget(center_widget, stretch=1)
        self.ui.right_layout.addWidget(batch_bottom_widget)

        # 初始化变量
        self.batch_file_path = None
        self.batch_result_df = None

    def batch_open_csv_file(self):
        """批量分析文件选择"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择批量分析文件", "", "CSV文件 (*.csv)"
        )
        if file_path:
            self.batch_file_path = file_path
            self.batch_file_text.setText(os.path.basename(file_path))
            self.ui.text_edit.append("已选择文件：" + os.path.basename(file_path))

    def run_batch_analysis(self):
        """执行批量分析"""
        if not self.batch_file_path:
            self.ui.text_edit.append("请先选择需要分析的CSV文件")
            return

        try:
            # 调用Batch_pla.py中的generate_figure函数
            from Batchpla import generate_figure
            result_df = generate_figure(self.batch_file_path)  # 修改此处，只接收一个返回值

            if result_df is None:
                self.ui.text_edit.append("错误：分析失败，结果为空")
                return

            self.batch_result_df = result_df
            self.ui.text_edit.append("批量分析完成，共处理{}条数据".format(len(result_df)))

            # 显示下载按钮
            self.btn_download.show()

        except Exception as e:
            self.ui.text_edit.append("分析过程中出错：" + str(e))
            self.batch_result_df = None
            self.btn_download.hide()

    def run_batch_tiss_analysis(self):
        """执行批量分析"""
        if not self.batch_file_path:
            self.ui.text_edit.append("请先选择需要分析的CSV文件")
            return

        try:
            from BatchTiss import generate_figure
            result_df = generate_figure(self.batch_file_path)

            if result_df is None:
                self.ui.text_edit.append("错误：分析失败，结果为空")
                return

            self.batch_result_df = result_df
            self.ui.text_edit.append("批量分析完成，共处理{}条数据".format(len(result_df)))

            # 显示下载按钮
            self.btn_download.show()

        except Exception as e:
            self.ui.text_edit.append("分析过程中出错：" + str(e))
            self.batch_result_df = None
            self.btn_download.hide()

    def download_results(self):
        """下载分析结果"""
        if self.batch_result_df is None:
            self.ui.text_edit.append("请先完成分析")
            return

        # 生成保存路径
        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存分析结果", "", "CSV文件 (*.csv)"
        )
        if save_path:
            try:
                self.batch_result_df.to_csv(save_path, index=False)
                self.ui.text_edit.append("结果已保存至：" + os.path.basename(save_path))
            except Exception as e:
                self.ui.text_edit.append("保存失败：" + str(e))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QtGui.QIcon(r"image/tubiao.png"))
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())