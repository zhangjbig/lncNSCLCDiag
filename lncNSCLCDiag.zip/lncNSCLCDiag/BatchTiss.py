import numpy as np
import pandas as pd
import os
import joblib

os.environ['PYTHONHASHSEED'] = str(66)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
np.random.seed(66)
import random

random.seed(66)

import sys

def get_resource_path(relative_path):
    """获取打包后资源的正确路径"""
    if hasattr(sys, '_MEIPASS'):
        # 打包后的环境
        return os.path.join(sys._MEIPASS, relative_path)
    # 开发环境
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)


def generate_figure(file_path):
    # 1. 加载数据
    try:
        data = pd.read_csv(file_path)
        print("数据加载成功")
    except FileNotFoundError:
        print("文件未找到，请检查文件路径是否正确。")
        return None, "文件加载失败"

    # 2. 提取特征
    X = data.iloc[:, 0:].values  # 特征数据

    # 3. 加载保存的MLP模型
    try:
        model = joblib.load('E:/github/model/best_MLP_model_fold_8_auc_0.9901.pkl')
        print("模型加载成功")
    except Exception as e:
        print(f"模型加载失败: {e}")
        return None

    # 设置最佳阈值
    best_threshold = 0.6587

    # 对新数据进行预测
    try:
        new_patient_pred = model.predict_proba(X)[:, 1]
        print("新患者预测概率:", new_patient_pred)
    except Exception as e:
        return None, f"患者预测过程中出现错误: {e}"

    # 创建结果DataFrame
    result_df = data.copy()

    # 添加三列结果
    result_df['Prediction_Probability'] = new_patient_pred.flatten()
    result_df['Prediction_Label'] = np.where(result_df['Prediction_Probability'] > best_threshold, "NSCLC", "Healthy")

    # 计算置信度
    def calculate_confidence(row):
        prob = row['Prediction_Probability']
        if prob > best_threshold:
            return (prob - best_threshold) / (1 - best_threshold) * 100
        else:
            return (best_threshold - prob) / best_threshold * 100

    result_df['Confidence_Percentage'] = result_df.apply(calculate_confidence, axis=1)

    return result_df