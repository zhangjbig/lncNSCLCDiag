import numpy as np
import pandas as pd
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
import os

os.environ['PYTHONHASHSEED'] = str(66)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
np.random.seed(66)
import random

random.seed(66)

import sys

def generate_figure(file_path):
    # 1. 加载数据
    try:
        data = pd.read_csv(file_path)
        print("数据加载成功")
    except FileNotFoundError:
        print("文件未找到，请检查文件路径是否正确。")
        return None, "文件加载失败"

    # 2. 提取特征
    X = data.iloc[:, 0:].values  # 特征数据

    # 3. 重新构建自动编码器
    input_dim = X.shape[1]
    encoding_dim = 64

    input_layer = Input(shape=(input_dim,))
    encoded = Dense(128, activation='relu')(input_layer)
    encoded = Dense(encoding_dim, activation='relu')(encoded)
    decoded = Dense(128, activation='relu')(encoded)
    decoded = Dense(input_dim, activation='linear')(decoded)

    autoencoder = Model(input_layer, decoded)
    encoder = Model(input_layer, encoded)
    autoencoder.compile(optimizer=Adam(learning_rate=0.0005), loss='mse')

    # 4. 加载模型权重
    try:
        autoencoder.load_weights('E:/github/model/gelu.0.0001autoencoder_weights_best_fold_1.weights.h5')
        print("自动编码器权重加载成功")
    except Exception as e:
        print(f"自动编码器权重加载失败: {e}")
        return None, "模型加载失败"

    try:
        model = load_model('E:/github/model/gelu.0.0001AERMLP_best_model_fold_1_auc_0.9952.h5')
        print("模型加载成功")
    except Exception as e:
        print(f"模型加载失败: {e}")
        return None, "模型加载失败"


    # 设置最佳阈值
    best_threshold = 0.1540

    # 使用编码器对新数据进行编码
    new_patient_encoded = encoder.predict(X)
    new_patient_encoded = new_patient_encoded.reshape(new_patient_encoded.shape[0], 1, new_patient_encoded.shape[1])

    # 对新数据进行预测
    try:
        new_patient_pred = model.predict(new_patient_encoded)
        print("新患者预测概率:", new_patient_pred)
    except Exception as e:
        return None, f"患者预测过程中出现错误: {e}"

    # 创建结果DataFrame
    result_df = data.copy()

    # 添加三列结果
    result_df['Prediction_Probability'] = new_patient_pred.flatten()
    result_df['Prediction_Label'] = np.where(result_df['Prediction_Probability'] > best_threshold, "NSCLC", "Healthy")

    # 计算置信度
    def calculate_confidence(row):
        prob = row['Prediction_Probability']
        if prob > best_threshold:
            return (prob - best_threshold) / (1 - best_threshold) * 100
        else:
            return (best_threshold - prob) / best_threshold * 100

    result_df['Confidence_Percentage'] = result_df.apply(calculate_confidence, axis=1)

    return result_df