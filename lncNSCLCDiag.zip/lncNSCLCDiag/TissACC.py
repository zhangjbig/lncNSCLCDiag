import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from scipy.stats import gaussian_kde
import joblib


def generate_figure(file_path):
    info = ""  # 提前定义info变量
    # 1. 加载数据
    try:
        data = pd.read_csv(file_path)
        print("数据加载成功")
    except FileNotFoundError:
        print("文件未找到，请检查文件路径是否正确。")
        return None

    # 2. 提取特征和标签
    X = data.iloc[:, 0:].values  # 特征数据

    # 3. 加载保存的MLP模型
    try:
        model = joblib.load('E:/github/model/best_MLP_model_fold_8_auc_0.9901.pkl')
        print("模型加载成功")
    except Exception as e:
        print(f"模型加载失败: {e}")
        return None

    # 直接设置最佳阈值
    best_threshold = 0.6587

    try:
        y_test_pred_prob = model.predict_proba(X)[:, 1]  # 获取阳性类别的概率
        print("新患者预测概率:", y_test_pred_prob)  # 查看模型预测概率
    except Exception as e:
        info += f"患者预测过程中出现错误: {e}\n"
        return None, info

    # 进行分类
    new_patient_pred_class = (y_test_pred_prob > best_threshold).astype(int)

    # 显示预测概率与置信度信息
    new_pred_prob = y_test_pred_prob[0]
    #info += f"患者预测概率为: {new_pred_prob:.4f}\n"
    #info += f"分类阈值为: {best_threshold:.4f}\n"

    if new_pred_prob > best_threshold:
        new_pred_label = "NSCLC"
        confidence = (new_pred_prob - best_threshold) / (1 - best_threshold)
    else:
        new_pred_label = "Healthy"
        confidence = (best_threshold - new_pred_prob) / best_threshold

    confidence_percentage = confidence * 100
    info += f"Patient prediction category: {new_pred_label}\n"  # \n添加换行符
    info += f"Confidence percentage: {confidence_percentage:.2f}%\n"

    # ===== 画出概率分布图（加载测试集预测概率 + 阈值） =====
    y_pred_prob = np.load('E:/github/model/tissue.best_y_test_pred_prob.npy').flatten()
    y_test = np.load('E:/github/model/tissue.best_y_test.npy')

    # 计算核密度估计
    kde_0 = gaussian_kde(y_pred_prob[y_test == 0])
    kde_1 = gaussian_kde(y_pred_prob[y_test == 1])
    x_vals = np.linspace(0, 1, 200)
    y_vals_0 = kde_0(x_vals)
    y_vals_1 = kde_1(x_vals)

    fig = plt.figure(figsize=(5,3))
    plt.plot(x_vals, y_vals_0, label='Healthy', color='skyblue')
    plt.plot(x_vals, y_vals_1, label='NSCLC', color='salmon')

    # 填充曲线下的区域
    plt.fill_between(x_vals, y_vals_0, color='skyblue', alpha=0.3)
    plt.fill_between(x_vals, y_vals_1, color='salmon', alpha=0.3)

    # 画最佳阈值
    plt.axvline(x=best_threshold, color='black', linestyle='--', linewidth=1,
                label=f'Cut-Off = {best_threshold:.4f}', ymin=0, ymax=0.3)

    # 画新样本的预测概率线
    plt.axvline(x=new_pred_prob, color='red', linestyle='--', linewidth=2,
                label=f'Patient Prediction = {new_pred_prob:.4f}')

    # 获取当前y轴的范围
    ymin, ymax = plt.ylim()
    # 计算y轴范围的中间值
    mid_y = (ymin + ymax) / 2
    # 添加菱形标记
    plt.plot(new_pred_prob, mid_y, '>b', markersize=10)

    #plt.title('Probability Distribution with New Sample')
    plt.xlabel('Predicted Probability')
    plt.ylabel('Density')
    plt.legend()
    plt.tight_layout()
    return fig, info