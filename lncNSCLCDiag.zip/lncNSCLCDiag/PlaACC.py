import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.optimizers import Adam
import os
import tensorflow as tf
# 设置随机种子
tf.random.set_seed(66)
os.environ['PYTHONHASHSEED'] = str(66)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
np.random.seed(66)
import random
random.seed(66)
from scipy.stats import gaussian_kde


def generate_figure(file_path):
    info = ""  # 提前定义info变量
    # 1. 加载数据
    try:
        data = pd.read_csv(file_path)
        print("数据加载成功")
    except FileNotFoundError:
        print("文件未找到，请检查文件路径是否正确。")
        return None

    # 2. 提取特征
    X = data.iloc[:, 0:].values

    # 3. 重新构建自动编码器（需要与训练时一致）
    input_dim = X.shape[1]
    encoding_dim = 64  # 编码器输出的维度

    input_layer = Input(shape=(input_dim,))
    encoded = Dense(128, activation='relu')(input_layer)
    encoded = Dense(encoding_dim, activation='relu')(encoded)
    decoded = Dense(128, activation='relu')(encoded)
    decoded = Dense(input_dim, activation='linear')(decoded)

    autoencoder = Model(input_layer, decoded)
    encoder = Model(input_layer, encoded)

    autoencoder.compile(optimizer=Adam(learning_rate=0.0005), loss='mse')

    # 这里需要加载训练时的自动编码器权重，假设保存了自动编码器的权重
    try:
        autoencoder.load_weights('E:/github/model/gelu.0.0001autoencoder_weights_best_fold_1.weights.h5')
        print("自动编码器权重加载成功")
    except Exception as e:
        print(f"自动编码器权重加载失败: {e}")
        return None

    # 4. 加载已保存的模型
    try:
        model = load_model('E:/github/model/gelu.0.0001AERMLP_best_model_fold_1_auc_0.9952.h5')
        print("模型加载成功")
    except Exception as e:
        print(f"模型加载失败: {e}")
        return None

    # 直接设置最佳阈值
    best_threshold = 0.1540

    # 新患者信息即为加载数据的特征
    new_patient_info = X

    # 使用编码器对新患者信息进行编码
    new_patient_encoded = encoder.predict(new_patient_info)

    # 调整数据维度为 (样本数, 时间步长, 特征数)
    new_patient_encoded = new_patient_encoded.reshape(new_patient_encoded.shape[0], 1, new_patient_encoded.shape[1])

    # 对新患者信息进行预测
    try:
        new_patient_pred = model.predict(new_patient_encoded)
        #info += "Done\n"
        print("新患者预测概率:", new_patient_pred)  # 查看模型预测概率
    except Exception as e:
        info += f"患者预测过程中出现错误: {e}\n"
        return None, info
    # 对新患者信息进行预测

    # 进行分类
    new_patient_pred_class = (new_patient_pred > best_threshold).astype(int)

    # 显示预测概率与置信度信息
    new_pred_prob = new_patient_pred[0][0]

    if new_pred_prob > best_threshold:
        new_pred_label = "NSCLC"
        confidence = (new_pred_prob - best_threshold) / (1 - best_threshold)
    else:
        new_pred_label = "Healthy"
        confidence = (best_threshold - new_pred_prob) / best_threshold

    confidence_percentage = confidence * 100
    info += f"Patient prediction category: {new_pred_label}\n"  # \n添加换行符
    info += f"Confidence percentage: {confidence_percentage:.2f}%\n"

    # ===== 画出概率分布图（加载测试集预测概率 + 阈值） =====
    y_pred_prob = np.load('E:/github/model/best_y_test_pred_prob.npy').flatten()
    y_test = np.load('E:/github/model/best_y_test.npy')

    # 计算核密度估计
    kde_0 = gaussian_kde(y_pred_prob[y_test == 0])
    kde_1 = gaussian_kde(y_pred_prob[y_test == 1])
    x_vals = np.linspace(0, 1, 200)
    y_vals_0 = kde_0(x_vals)
    y_vals_1 = kde_1(x_vals)

    fig = plt.figure(figsize=(5,3))
    plt.plot(x_vals, y_vals_0, label='Healthy', color='skyblue')
    plt.plot(x_vals, y_vals_1, label='NSCLC', color='salmon')

    # 填充曲线下的区域
    plt.fill_between(x_vals, y_vals_0, color='skyblue', alpha=0.3)
    plt.fill_between(x_vals, y_vals_1, color='salmon', alpha=0.3)

    # 画最佳阈值
    plt.axvline(x=best_threshold, color='black', linestyle='--', linewidth=1,
                label=f'Cut-Off = {best_threshold:.4f}', ymin=0, ymax=0.3)

    # 画新样本的预测概率线
    plt.axvline(x=new_pred_prob, color='red', linestyle='--', linewidth=2,
                label=f'Patient Prediction = {new_pred_prob:.4f}')

    # 获取当前y轴的范围
    ymin, ymax = plt.ylim()
    # 计算y轴范围的中间值
    mid_y = (ymin + ymax) / 2
    # 添加菱形标记
    plt.plot(new_pred_prob, mid_y, '>b', markersize=10)

    #plt.title('Probability Distribution with New Sample')
    plt.xlabel('Predicted Probability')
    plt.ylabel('Density')
    plt.legend()
    plt.tight_layout()
    return fig, info